import React, { useState, createContext, useContext, useEffect } from 'react';
import './App.css'; // Importing the CSS file

// Define the AuthContext to hold the user's authentication state.
const AuthContext = createContext(null);

// AuthProvider component to wrap the entire application.
const AuthProvider = ({ children }) => {
  // We'll use a simple mock user for demonstration.
  const [user, setUser] = useState(null);
  const [mockUsers, setMockUsers] = useState({
    sysadmin: { password: 'Sys@dmin1', role: 'System Administrator' },
    storeowner1: { password: 'St0re@wner1', role: 'Store Owner' },
    normaluser1: { password: 'Norm@luser1', role: 'Normal User' }
  });

  // The login function that simulates a backend API call.
  const login = (username, password) => {
    return new Promise(resolve => {
      setTimeout(() => {
        const userData = mockUsers[username];
        if (userData && userData.password === password) {
          setUser({ username: username, role: userData.role });
          resolve(true); // Login successful
        } else {
          resolve(false); // Login failed
        }
      }, 500);
    });
  };

  // The register function to handle new user sign-ups, simulating an API call.
  const register = (username, email, password) => {
    console.log(`Simulating registration for: Username: ${username}, Email: ${email}`);
    // Assume registration is always successful for this demo.
    return new Promise(resolve => {
      setTimeout(() => {
        setMockUsers(prevUsers => ({
          ...prevUsers,
          [username]: { password: password, role: 'Normal User' }
        }));
        resolve(true);
      }, 500);
    });
  };
  
  // Functions to update user passwords.
  const updateNormalUserPassword = (username, newPassword) => {
    setMockUsers(prevUsers => ({
      ...prevUsers,
      [username]: { ...prevUsers[username], password: newPassword }
    }));
  };
  
  const updateStoreOwnerPassword = (username, newPassword) => {
    setMockUsers(prevUsers => ({
      ...prevUsers,
      [username]: { ...prevUsers[username], password: newPassword }
    }));
  };

  // The logout function.
  const logout = () => {
    setUser(null);
  };

  const value = { user, login, register, logout, updateNormalUserPassword, updateStoreOwnerPassword };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// --- LOGIN COMPONENT ---
const LoginPage = ({ onLoginSuccess, onGoToSignup }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useContext(AuthContext);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const success = await login(username, password);
    if (success) {
      onLoginSuccess();
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="flex-center-container">
      <div className="login-card">
        <h2 className="login-title">Welcome</h2>
        <form onSubmit={handleSubmit} className="login-form">
          {error && <p className="error-message">{error}</p>}
          <div>
            <input
              type="text"
              id="username"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="login-input"
              required
            />
          </div>
          <div>
            <input
              type="password"
              id="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="login-input"
              required
            />
          </div>
          <button
            type="submit"
            className="login-button"
          >
            Log In
          </button>
        </form>
        <p className="signup-link-text">
          Not a member?{' '}
          <a href="#" onClick={onGoToSignup} className="signup-link">
            Sign Up
          </a>
        </p>
      </div>
    </div>
  );
};

// --- SIGN UP COMPONENT ---
const SignUpPage = ({ onRegisterSuccess, onGoToLogin }) => {
  const [newUserData, setNewUserData] = useState({ name: '', email: '', password: '', address: '' });
  const [errors, setErrors] = useState({});
  const [registrationError, setRegistrationError] = useState('');
  const { register } = useContext(AuthContext);

  const validateForm = () => {
    const newErrors = {};
    if (!newUserData.name || newUserData.name.length < 20 || newUserData.name.length > 60) {
      newErrors.name = 'Name must be between 20 and 60 characters.';
    }
    if (!newUserData.email) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(newUserData.email)) {
      newErrors.email = 'Email address is invalid.';
    }
    if (!newUserData.password || newUserData.password.length < 8 || newUserData.password.length > 16) {
      newErrors.password = 'Password must be 8-16 characters long.';
    } else if (!/[A-Z]/.test(newUserData.password) || !/[!@#$%^&*(),.?":{}|<>]/.test(newUserData.password)) {
      newErrors.password = 'Password must include at least one uppercase letter and one special character.';
    }
    if (!newUserData.address || newUserData.address.length > 400) {
      newErrors.address = 'Address cannot exceed 400 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRegistrationError('');
    if (validateForm()) {
      const success = await register(newUserData.name, newUserData.email, newUserData.password);
      if (success) {
        onRegisterSuccess();
      } else {
        setRegistrationError('Registration failed. Please try again.');
      }
    }
  };

  return (
    <div className="flex-center-container">
      <div className="signup-card">
        <h2 className="signup-title">Sign Up</h2>
        <form onSubmit={handleSubmit} className="signup-form">
          {registrationError && <p className="error-message">{registrationError}</p>}
          <div className="input-group">
            <input
              type="text"
              placeholder="Full Name (20-60 chars)"
              value={newUserData.name}
              onChange={(e) => setNewUserData({...newUserData, name: e.target.value})}
              className={`signup-input ${errors.name ? 'input-error' : ''}`}
            />
            {errors.name && <p className="input-error-message">{errors.name}</p>}
          </div>
          <div className="input-group">
            <input
              type="email"
              placeholder="Email Address"
              value={newUserData.email}
              onChange={(e) => setNewUserData({...newUserData, email: e.target.value})}
              className={`signup-input ${errors.email ? 'input-error' : ''}`}
            />
            {errors.email && <p className="input-error-message">{errors.email}</p>}
          </div>
          <div className="input-group">
            <input
              type="password"
              placeholder="Password (8-16 chars, 1 uppercase, 1 special)"
              value={newUserData.password}
              onChange={(e) => setNewUserData({...newUserData, password: e.target.value})}
              className={`signup-input ${errors.password ? 'input-error' : ''}`}
            />
            {errors.password && <p className="input-error-message">{errors.password}</p>}
          </div>
          <div className="input-group">
            <textarea
              placeholder="Address (max 400 chars)"
              value={newUserData.address}
              onChange={(e) => setNewUserData({...newUserData, address: e.target.value})}
              className={`signup-input ${errors.address ? 'input-error' : ''}`}
              rows="3"
            />
            {errors.address && <p className="input-error-message">{errors.address}</p>}
          </div>
          <button
            type="submit"
            className="signup-button"
          >
            Sign Up
          </button>
        </form>
        <p className="login-link-text">
          Already have an account?{' '}
          <a href="#" onClick={onGoToLogin} className="login-link">
            Log In
          </a>
        </p>
      </div>
    </div>
  );
};

// --- SYSTEM ADMINISTRATOR DASHBOARD COMPONENT ---
const SysAdminDashboardPage = () => {
  const { user, logout } = useContext(AuthContext);
  const [newUserData, setNewUserData] = useState({ name: '', email: '', password: '', address: '', role: 'Normal User' });
  const [errors, setErrors] = useState({});
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john.d@example.com', address: '123 Main St', role: 'Normal User' },
    { id: 2, name: 'Jane Smith', email: 'jane.s@example.com', address: '456 Oak Ave', role: 'Store Owner', rating: 4.5 },
    { id: 3, name: 'Admin User', email: 'admin.u@example.com', address: '789 Pine Rd', role: 'System Administrator' },
    { id: 4, name: 'Bob Johnson', email: 'bob.j@example.com', address: '101 Elm Blvd', role: 'Normal User' },
    { id: 5, name: 'Store Owner 2', email: 'so2@example.com', address: '202 Maple Dr', role: 'Store Owner', rating: 3.8 },
  ]);
  const [stores, setStores] = useState([
    { id: 1, name: 'The Coffee Shop', email: 'coffee@shop.com', address: '123 Main St', rating: 4.5 },
    { id: 2, name: 'Bookworms Inc.', email: 'books@inc.com', address: '456 Oak Ave', rating: 4.8 },
    { id: 3, name: 'The Tech Hub', email: 'tech@hub.com', address: '789 Pine Rd', rating: 4.2 },
  ]);
  const [searchTerm, setSearchTerm] = useState('');

  const totalUsers = users.length;
  const totalStores = stores.length;
  const totalRatings = stores.reduce((sum, store) => sum + store.rating, 0).toFixed(1);

  const handleFilterChange = (e) => {
    setSearchTerm(e.target.value);
  };
  
  const validateAddUserForm = () => {
    const newErrors = {};
    if (!newUserData.name || newUserData.name.length < 20 || newUserData.name.length > 60) {
      newErrors.name = 'Name must be between 20 and 60 characters.';
    }
    if (!newUserData.email) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(newUserData.email)) {
      newErrors.email = 'Email address is invalid.';
    }
    if (!newUserData.password || newUserData.password.length < 8 || newUserData.password.length > 16) {
      newErrors.password = 'Password must be 8-16 characters long.';
    } else if (!/[A-Z]/.test(newUserData.password) || !/[!@#$%^&*(),.?":{}|<>]/.test(newUserData.password)) {
      newErrors.password = 'Password must include at least one uppercase letter and one special character.';
    }
    if (!newUserData.address || newUserData.address.length > 400) {
      newErrors.address = 'Address cannot exceed 400 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddUser = (e) => {
    e.preventDefault();
    if (validateAddUserForm()) {
      const newUser = {
        id: users.length + 1,
        name: newUserData.name,
        email: newUserData.email,
        address: newUserData.address,
        role: newUserData.role,
      };
      setUsers([...users, newUser]);
      setNewUserData({ name: '', email: '', password: '', address: '', role: 'Normal User' });
      setErrors({});
      console.log('Added new user:', newUser);
    }
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1 className="dashboard-title">Admin Dashboard</h1>
        <div className="user-info-container">
          <p className="user-info">Logged in as: <span className="user-info-highlight">{user.username}</span></p>
          <button onClick={logout} className="logout-button">
            Logout
          </button>
        </div>
      </header>

      {/* Stats Overview Section */}
      <div className="stats-grid">
        <div className="stat-card stat-users">
          <h3 className="stat-title">Total Users</h3>
          <p className="stat-value">{totalUsers}</p>
        </div>
        <div className="stat-card stat-stores">
          <h3 className="stat-title">Total Stores</h3>
          <p className="stat-value">{totalStores}</p>
        </div>
        <div className="stat-card stat-ratings">
          <h3 className="stat-title">Total Ratings</h3>
          <p className="stat-value">{totalRatings}</p>
        </div>
      </div>

      {/* User Management Section */}
      <div className="card">
        <h2 className="section-title">User Management</h2>
        
        {/* Add New User Form */}
        <div className="sub-card">
          <h3 className="sub-title">Add New User</h3>
          <form onSubmit={handleAddUser} className="form-grid">
            <input type="text" placeholder="Name" value={newUserData.name} onChange={(e) => setNewUserData({...newUserData, name: e.target.value})} className={`form-input ${errors.name ? 'input-error' : ''}`} />
            {errors.name && <p className="input-error-message form-col-span-2">{errors.name}</p>}
            
            <input type="email" placeholder="Email" value={newUserData.email} onChange={(e) => setNewUserData({...newUserData, email: e.target.value})} className={`form-input ${errors.email ? 'input-error' : ''}`} />
            {errors.email && <p className="input-error-message form-col-span-2">{errors.email}</p>}
            
            <input type="password" placeholder="Password" value={newUserData.password} onChange={(e) => setNewUserData({...newUserData, password: e.target.value})} className={`form-input ${errors.password ? 'input-error' : ''}`} />
            {errors.password && <p className="input-error-message form-col-span-2">{errors.password}</p>}
            
            <input type="text" placeholder="Address" value={newUserData.address} onChange={(e) => setNewUserData({...newUserData, address: e.target.value})} className={`form-input ${errors.address ? 'input-error' : ''}`} />
            {errors.address && <p className="input-error-message form-col-span-2">{errors.address}</p>}
            
            <select value={newUserData.role} onChange={(e) => setNewUserData({...newUserData, role: e.target.value})} className="form-input">
              <option value="Normal User">Normal User</option>
              <option value="Store Owner">Store Owner</option>
              <option value="System Administrator">System Administrator</option>
            </select>
            <button type="submit" className="form-button-green">Add User</button>
          </form>
        </div>

        {/* User List */}
        <h3 className="sub-title">User List</h3>
        <input
          type="text"
          placeholder="Filter users..."
          value={searchTerm}
          onChange={handleFilterChange}
          className="filter-input"
        />
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr className="table-header-row">
                <th className="table-header">Name</th>
                <th className="table-header">Email</th>
                <th className="table-header">Address</th>
                <th className="table-header">Role</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(u => (
                <tr key={u.id} className="table-row">
                  <td className="table-cell">{u.name}</td>
                  <td className="table-cell">{u.email}</td>
                  <td className="table-cell">{u.address}</td>
                  <td className="table-cell">
                    {u.role}
                    {u.role === 'Store Owner' && <span className="star-rating">- {u.rating} ★</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Store Management Section */}
      <div className="card">
        <h2 className="section-title">Store Management</h2>
        <input
          type="text"
          placeholder="Filter stores..."
          value={searchTerm}
          onChange={handleFilterChange}
          className="filter-input"
        />
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr className="table-header-row">
                <th className="table-header">Name</th>
                <th className="table-header">Email</th>
                <th className="table-header">Address</th>
                <th className="table-header">Rating</th>
              </tr>
            </thead>
            <tbody>
              {filteredStores.map(store => (
                <tr key={store.id} className="table-row">
                  <td className="table-cell">{store.name}</td>
                  <td className="table-cell">{store.email}</td>
                  <td className="table-cell">{store.address}</td>
                  <td className="table-cell star-rating">{store.rating} ★</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// --- NORMAL USER DASHBOARD COMPONENT ---
const NormalUserDashboardPage = () => {
  const { user, logout, updateNormalUserPassword } = useContext(AuthContext);
  const [stores, setStores] = useState([
    { id: 1, name: 'The Coffee Shop', address: '123 Main St', overallRating: 4.5, userRating: 0 },
    { id: 2, name: 'Bookworms Inc.', address: '456 Oak Ave', overallRating: 4.8, userRating: 0 },
    { id: 3, name: 'The Tech Hub', address: '789 Pine Rd', overallRating: 4.2, userRating: 0 },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [passwordChange, setPasswordChange] = useState({ new: '', confirm: '' });
  const [passwordMessage, setPasswordMessage] = useState('');
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  const handleRatingSubmit = (storeId, newRating) => {
    setStores(stores.map(store => 
      store.id === storeId ? { ...store, userRating: newRating } : store
    ));
    console.log(`Rating for store ${storeId} submitted: ${newRating}`);
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const validatePasswordChange = () => {
    const { new: newPassword, confirm } = passwordChange;
    if (newPassword !== confirm) {
      setPasswordMessage('New passwords do not match.');
      return false;
    }
    if (newPassword.length < 8 || newPassword.length > 16) {
      setPasswordMessage('New password must be 8-16 characters long.');
      return false;
    }
    if (!/[A-Z]/.test(newPassword) || !/[!@#$%^&*(),.?":{}|<>]/.test(newPassword)) {
      setPasswordMessage('New password must include at least one uppercase letter and one special character.');
      return false;
    }
    return true;
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    setPasswordMessage('');
    if (validatePasswordChange()) {
      updateNormalUserPassword(user.username, passwordChange.new);
      setPasswordMessage('Password updated successfully! You can now log in with your new password.');
      setPasswordChange({ new: '', confirm: '' });
    }
  };

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1 className="dashboard-title">Normal User Dashboard</h1>
        <div className="user-info-container">
          <p className="user-info">Logged in as: <span className="user-info-highlight">{user.username}</span></p>
          <button onClick={logout} className="logout-button">
            Logout
          </button>
        </div>
      </header>

      {/* Store Ratings Section */}
      <div className="card">
        <h2 className="section-title">Store Ratings</h2>
        <input
          type="text"
          placeholder="Search stores by name or address..."
          value={searchTerm}
          onChange={handleSearch}
          className="filter-input"
        />
        <div className="store-list-grid">
          {filteredStores.map(store => (
            <div key={store.id} className="store-rating-card">
              <h3 className="store-name">{store.name}</h3>
              <p className="store-address">{store.address}</p>
              <p className="overall-rating">Overall Rating: <span className="star-rating-overall">{store.overallRating} ★</span></p>
              <p className="user-rating">Your Rating: <span className="user-rating-value">{store.userRating > 0 ? `${store.userRating} ★` : 'Not rated'}</span></p>
              <div className="rating-buttons-container">
                <span className="rating-label">Submit/Update:</span>
                {[1, 2, 3, 4, 5].map(rating => (
                  <button
                    key={rating}
                    onClick={() => handleRatingSubmit(store.id, rating)}
                    className={`rating-button ${rating <= store.userRating ? 'rated' : ''}`}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Update Password Section */}
      <div className="card">
        <h2 className="section-title">Update Password</h2>
        <button onClick={() => setShowPasswordForm(!showPasswordForm)} className="toggle-password-form-button">
          {showPasswordForm ? 'Hide Form' : 'Show Password Form'}
        </button>
        {showPasswordForm && (
          <form onSubmit={handlePasswordChange} className="password-form">
            {passwordMessage && <p className={`password-message ${passwordMessage.includes('successfully') ? 'message-success' : 'message-error'}`}>{passwordMessage}</p>}
            <input type="password" placeholder="New Password" value={passwordChange.new} onChange={(e) => setPasswordChange({ ...passwordChange, new: e.target.value })} required className="form-input" />
            <input type="password" placeholder="Confirm New Password" value={passwordChange.confirm} onChange={(e) => setPasswordChange({ ...passwordChange, confirm: e.target.value })} required className="form-input" />
            <button type="submit" className="form-button-green">
              Update Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

// --- STORE OWNER DASHBOARD COMPONENT ---
const StoreOwnerDashboardPage = () => {
  const { user, logout, updateStoreOwnerPassword } = useContext(AuthContext);
  const [passwordChange, setPasswordChange] = useState({ new: '', confirm: '' });
  const [passwordMessage, setPasswordMessage] = useState('');
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  const storeData = {
    name: 'Bookworms Inc.',
    averageRating: 4.8,
    usersWhoRated: [
      { id: 1, name: 'Normal User 1', email: 'normaluser1@example.com', rating: 5 },
      { id: 2, name: 'Normal User 2', email: 'normaluser2@example.com', rating: 4 },
      { id: 3, name: 'Normal User 3', email: 'normaluser3@example.com', rating: 5 },
    ],
  };

  const validatePasswordChange = () => {
    const { new: newPassword, confirm } = passwordChange;
    if (newPassword !== confirm) {
      setPasswordMessage('New passwords do not match.');
      return false;
    }
    if (newPassword.length < 8 || newPassword.length > 16) {
      setPasswordMessage('New password must be 8-16 characters long.');
      return false;
    }
    if (!/[A-Z]/.test(newPassword) || !/[!@#$%^&*(),.?":{}|<>]/.test(newPassword)) {
      setPasswordMessage('New password must include at least one uppercase letter and one special character.');
      return false;
    }
    return true;
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    setPasswordMessage('');
    if (validatePasswordChange()) {
      updateStoreOwnerPassword(user.username, passwordChange.new);
      setPasswordMessage('Password updated successfully! You can now log in with your new password.');
      setPasswordChange({ new: '', confirm: '' });
    }
  };

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1 className="dashboard-title">Store Owner Dashboard</h1>
        <div className="user-info-container">
          <p className="user-info">Logged in as: <span className="user-info-highlight">{user.username}</span></p>
          <button onClick={logout} className="logout-button">
            Logout
          </button>
        </div>
      </header>

      {/* Store Overview Section */}
      <div className="card">
        <h2 className="section-title">{storeData.name} Overview</h2>
        <div className="overview-card">
          <h3 className="overview-title">Average Rating</h3>
          <p className="overview-value">{storeData.averageRating} ★</p>
        </div>
      </div>

      {/* User Ratings Section */}
      <div className="card">
        <h2 className="section-title">User Ratings for Your Store</h2>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr className="table-header-row">
                <th className="table-header">User Name</th>
                <th className="table-header">Email</th>
                <th className="table-header">Rating</th>
              </tr>
            </thead>
            <tbody>
              {storeData.usersWhoRated.map(user => (
                <tr key={user.id} className="table-row">
                  <td className="table-cell">{user.name}</td>
                  <td className="table-cell">{user.email}</td>
                  <td className="table-cell star-rating">{user.rating} ★</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Update Password Section */}
      <div className="card">
        <h2 className="section-title">Update Password</h2>
        <button onClick={() => setShowPasswordForm(!showPasswordForm)} className="toggle-password-form-button">
          {showPasswordForm ? 'Hide Form' : 'Show Password Form'}
        </button>
        {showPasswordForm && (
          <form onSubmit={handlePasswordChange} className="password-form">
            {passwordMessage && <p className={`password-message ${passwordMessage.includes('successfully') ? 'message-success' : 'message-error'}`}>{passwordMessage}</p>}
            <input type="password" placeholder="New Password" value={passwordChange.new} onChange={(e) => setPasswordChange({ ...passwordChange, new: e.target.value })} required className="form-input" />
            <input type="password" placeholder="Confirm New Password" value={passwordChange.confirm} onChange={(e) => setPasswordChange({ ...passwordChange, confirm: e.target.value })} required className="form-input" />
            <button type="submit" className="form-button-green">
              Update Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
};


// --- MAIN APP COMPONENT FOR ROUTING ---
const App = () => {
  const { user } = useContext(AuthContext);
  const [currentPage, setCurrentPage] = useState('login');

  useEffect(() => {
    // If a user is logged in, redirect them to the appropriate dashboard.
    if (user) {
      setCurrentPage('dashboard');
    }
  }, [user]);

  // Conditional rendering based on the current page and user role.
  switch (currentPage) {
    case 'login':
      return <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
    case 'signup':
      return <SignUpPage onRegisterSuccess={() => setCurrentPage('login')} onGoToLogin={() => setCurrentPage('login')} />;
    case 'dashboard':
      if (user && user.role === 'System Administrator') {
        return <SysAdminDashboardPage />;
      }
      if (user && user.role === 'Normal User') {
        return <NormalUserDashboardPage />;
      }
      if (user && user.role === 'Store Owner') {
        return <StoreOwnerDashboardPage />;
      }
      // If user is null but somehow on dashboard, redirect to login
      return <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
    default:
      return <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
  }
};

// This is the default export required by the system.
// We wrap our App with the AuthProvider to make the authentication context available everywhere.
const WrappedApp = () => (
  <div className="app-container">
    <AuthProvider>
      <App />
    </AuthProvider>
  </div>
);

export default WrappedApp;
