// src/content/AuthContext.js

import React, { useState, createContext } from 'react';

// Define the AuthContext to hold the user's authentication state.
const AuthContext = createContext(null);

// AuthProvider component to wrap the entire application.
const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = (username, password) => {
    // --- MOCK BACKEND API CALL ---
    return new Promise(resolve => {
      setTimeout(() => {
        if (username === 'test' && password === 'password') {
          setUser({ username: 'test', role: 'normal' });
          resolve(true);
        } else {
          resolve(false);
        }
      }, 500);
    });
  };

  const register = (username, email, password) => {
    // --- MOCK BACKEND API CALL ---
    console.log(`Simulating registration for: Username: ${username}, Email: ${email}`);
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(true);
      }, 500);
    });
  };

  const logout = () => {
    setUser(null);
  };

  const value = { user, login, register, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export { AuthContext, AuthProvider };