import React, { useState, useContext } from 'react';
import { AuthContext } from '../../content/AuthContext';

const NormalUserDashboardPage = () => {
  const { user, logout } = useContext(AuthContext);

  // Mock Data for stores and their ratings
  const [stores, setStores] = useState([
    { id: 1, name: 'The Coffee Shop', address: '123 Main St', overallRating: 4.5, userRating: 0 },
    { id: 2, name: 'Bookworms Inc.', address: '456 Oak Ave', overallRating: 4.8, userRating: 0 },
    { id: 3, name: 'The Tech Hub', address: '789 Pine Rd', overallRating: 4.2, userRating: 0 },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [passwordChange, setPasswordChange] = useState({ current: '', new: '', confirm: '' });
  const [passwordMessage, setPasswordMessage] = useState('');
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  const handleRatingSubmit = (storeId, newRating) => {
    setStores(stores.map(store =>
      store.id === storeId ? { ...store, userRating: newRating } : store
    ));
    // In a real app, you would make an API call here to save the rating.
    console.log(`Rating for store ${storeId} submitted: ${newRating}`);
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    setPasswordMessage('');
    if (passwordChange.new !== passwordChange.confirm) {
      setPasswordMessage('New passwords do not match.');
      return;
    }
    // In a real app, you would make an API call to change the password.
    console.log('Password change submitted:', passwordChange);
    setPasswordMessage('Password updated successfully!');
    setPasswordChange({ current: '', new: '', confirm: '' });
  };

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{
      fontFamily: 'sans-serif',
      backgroundColor: '#f4f7f9',
      minHeight: '100vh',
      padding: '2rem'
    }}>
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem 0',
        borderBottom: '2px solid #e0e0e0',
        marginBottom: '2rem'
      }}>
        <h1 style={{ color: '#333', fontSize: '2em' }}>Normal User Dashboard</h1>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <p style={{ marginRight: '1rem', color: '#555' }}>Logged in as: <span style={{ fontWeight: 'bold' }}>{user.username}</span></p>
          <button onClick={logout} style={{
            backgroundColor: '#ef4444',
            color: 'white',
            fontWeight: 'bold',
            padding: '0.5rem 1rem',
            borderRadius: '0.5rem',
            border: 'none',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}>
            Logout
          </button>
        </div>
      </header>

      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>Store Ratings</h2>
        <div style={{ marginBottom: '1rem' }}>
          <input
            type="text"
            placeholder="Search stores by name or address..."
            value={searchTerm}
            onChange={handleSearch}
            style={{ width: '100%', padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }}
          />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
          {filteredStores.map(store => (
            <div key={store.id} style={{ padding: '1rem', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#fafafa' }}>
              <h3 style={{ fontSize: '1.25em', fontWeight: 'bold', color: '#333' }}>{store.name}</h3>
              <p style={{ color: '#666', fontSize: '0.9em' }}>{store.address}</p>
              <p style={{ color: '#555', marginTop: '0.5rem' }}>Overall Rating: <span style={{ fontWeight: 'bold', color: '#f59e0b' }}>{store.overallRating} ★</span></p>
              <p style={{ color: '#555' }}>Your Rating: <span style={{ fontWeight: 'bold' }}>{store.userRating > 0 ? `${store.userRating} ★` : 'Not rated'}</span></p>
              <div style={{ marginTop: '0.5rem' }}>
                <span style={{ marginRight: '1rem' }}>Submit/Update Rating:</span>
                {[1, 2, 3, 4, 5].map(rating => (
                  <button
                    key={rating}
                    onClick={() => handleRatingSubmit(store.id, rating)}
                    style={{
                      border: 'none',
                      backgroundColor: 'transparent',
                      cursor: 'pointer',
                      fontSize: '1.2rem',
                      color: rating <= store.userRating ? '#f59e0b' : '#ccc',
                      transition: 'color 0.2s'
                    }}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>Update Password</h2>
        <button onClick={() => setShowPasswordForm(!showPasswordForm)} style={{
          backgroundColor: '#2575fc',
          color: 'white',
          padding: '0.75rem 1.5rem',
          borderRadius: '0.5rem',
          border: 'none',
          cursor: 'pointer',
          transition: 'background-color 0.3s'
        }}>
          {showPasswordForm ? 'Hide Form' : 'Show Password Form'}
        </button>
        {showPasswordForm && (
          <form onSubmit={handlePasswordChange} style={{ marginTop: '1.5rem' }}>
            {passwordMessage && <p style={{ color: passwordMessage.includes('successfully') ? 'green' : 'red', marginBottom: '1rem' }}>{passwordMessage}</p>}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
              <input type="password" placeholder="Current Password" value={passwordChange.current} onChange={(e) => setPasswordChange({ ...passwordChange, current: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <input type="password" placeholder="New Password" value={passwordChange.new} onChange={(e) => setPasswordChange({ ...passwordChange, new: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <input type="password" placeholder="Confirm New Password" value={passwordChange.confirm} onChange={(e) => setPasswordChange({ ...passwordChange, confirm: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <button type="submit" style={{
                backgroundColor: '#4CAF50', color: 'white', padding: '0.75rem 1.5rem', border: 'none', borderRadius: '5px', cursor: 'pointer', transition: 'background-color 0.3s'
              }}>
                Update Password
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default NormalUserDashboardPage;
