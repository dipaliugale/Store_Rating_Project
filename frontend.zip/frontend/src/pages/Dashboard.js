// src/pages/Dashboard.js

import React, { useContext } from 'react';
import { AuthContext } from '../content/AuthContext';

const DashboardPage = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-lg text-center">
        <h2 className="text-4xl font-extrabold text-blue-600 mb-4">Welcome, {user.username}!</h2>
        <p className="text-lg text-gray-600 mb-8">This is your personalized dashboard.</p>
        <button
          onClick={logout}
          className="bg-red-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-red-600 transition-colors"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default DashboardPage;