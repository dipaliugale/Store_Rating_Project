// App.js - The main component of the application.
// This single file contains all the components and logic for a store rating platform frontend.
// It uses React Hooks for state management and context for global state sharing.
import React, { useState, createContext, useContext, useEffect } from 'react';

// Define the AuthContext to hold the user's authentication state.
// This allows any component to access the user, and login/logout functions.
const AuthContext = createContext(null);

// AuthProvider component to wrap the entire application.
// It manages the user state and provides it to all its children.
const AuthProvider = ({ children }) => {
  // We'll use a simple mock user for demonstration. In a real app, this would be
  // populated with data from your backend.
  const [user, setUser] = useState(null);

  // The login function that would call your backend API.
  // It takes a username and password and, if successful, sets the user state.
  const login = (username, password) => {
    // --- MOCK BACKEND API CALL ---
    // This part of the code simulates a backend login process.
    // In a real application, you would replace this with an actual fetch() call to your backend.
    return new Promise(resolve => {
      setTimeout(() => {
        let role = '';
        if (username === 'sysadmin' && password === 'Sys@dmin1') {
          role = 'System Administrator';
        } else if (username === 'storeowner1' && password === 'St0re@wner1') {
          role = 'Store Owner';
        } else if (username === 'normaluser1' && password === 'Norm@luser1') {
          role = 'Normal User';
        }

        if (role) {
          setUser({ username: username, role: role });
          resolve(true); // Login successful
        } else {
          resolve(false); // Login failed
        }
      }, 500);
    });
  };

  // The register function to handle new user sign-ups.
  // This simulates an API call to create a new user account.
  const register = (username, email, password) => {
    // --- MOCK BACKEND API CALL ---
    // In a real application, you would make a fetch() call to your backend's registration endpoint.
    console.log(`Simulating registration for: Username: ${username}, Email: ${email}`);
    // Assume registration is always successful for this demo.
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(true);
      }, 500);
    });
  };

  // The logout function. In a real app, this would call a logout endpoint.
  const logout = () => {
    setUser(null);
  };

  // The value provided to all consuming components.
  const value = { user, login, register, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// A component for the login page.
// It includes a form to get user credentials and handles the login action.
const LoginPage = ({ onLoginSuccess, onGoToSignup }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useContext(AuthContext);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const success = await login(username, password);
    if (success) {
      onLoginSuccess();
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4" style={{
      background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
      minHeight: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '2.5rem',
        borderRadius: '15px',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '350px',
        textAlign: 'center',
        fontFamily: 'sans-serif'
      }}>
        <h2 style={{
          fontSize: '2em',
          fontWeight: 'bold',
          marginBottom: '1.5em',
          color: '#333'
        }}>Login</h2>
        <form onSubmit={handleSubmit}>
          {error && <p style={{ color: 'red', fontSize: '0.875em', textAlign: 'center', marginBottom: '1rem' }}>{error}</p>}
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="username">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: '2px solid #ccc',
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = '#ccc'}
            />
          </div>
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: '2px solid #ccc',
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = '#ccc'}
            />
          </div>
          <button
            type="submit"
            style={{
              width: '100%',
              padding: '1em',
              border: 'none',
              borderRadius: '25px',
              backgroundColor: '#2575fc',
              color: 'white',
              fontSize: '1.1em',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'background-color 0.3s, transform 0.2s'
            }}
            onMouseOver={(e) => e.target.style.backgroundColor = '#1a5acb'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#2575fc'}
          >
            Login
          </button>
        </form>
        <div style={{ textAlign: 'center', marginTop: '1.5rem' }}>
          <p style={{ fontSize: '0.9em', color: '#555' }}>
            Not a member?{' '}
            <a href="#" onClick={onGoToSignup} style={{ color: '#2575fc', textDecoration: 'none' }}>
              Sign Up
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

// A new component for the registration page.
// It includes a form for new users to create an account.
const SignUpPage = ({ onRegisterSuccess, onGoToLogin }) => {
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    password: '',
    address: ''
  });
  const [errors, setErrors] = useState({});
  const [registrationError, setRegistrationError] = useState('');
  const { register } = useContext(AuthContext);

  const validateForm = () => {
    const newErrors = {};
    if (!newUserData.name || newUserData.name.length < 20 || newUserData.name.length > 60) {
      newErrors.name = 'Name must be between 20 and 60 characters.';
    }
    if (!newUserData.email) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(newUserData.email)) {
      newErrors.email = 'Email address is invalid.';
    }
    if (!newUserData.password || newUserData.password.length < 8 || newUserData.password.length > 16) {
      newErrors.password = 'Password must be 8-16 characters long.';
    } else if (!/[A-Z]/.test(newUserData.password) || !/[!@#$%^&*(),.?":{}|<>]/.test(newUserData.password)) {
      newErrors.password = 'Password must include at least one uppercase letter and one special character.';
    }
    if (!newUserData.address || newUserData.address.length > 400) {
      newErrors.address = 'Address cannot exceed 400 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRegistrationError('');
    if (validateForm()) {
      const success = await register(newUserData.name, newUserData.email, newUserData.password);
      if (success) {
        onRegisterSuccess();
      } else {
        setRegistrationError('Registration failed. Please try again.');
      }
    }
  };

  return (
    <div style={{
      background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
      minHeight: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      fontFamily: 'sans-serif'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '2.5rem',
        borderRadius: '15px',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '350px',
        textAlign: 'center'
      }}>
        <h2 style={{
          fontSize: '2em',
          fontWeight: 'bold',
          marginBottom: '1.5em',
          color: '#333'
        }}>Sign Up</h2>
        <form onSubmit={handleSubmit}>
          {registrationError && <p style={{ color: 'red', fontSize: '0.875em', textAlign: 'center', marginBottom: '1rem' }}>{registrationError}</p>}
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="name">
              Name
            </label>
            <input
              type="text"
              id="name"
              value={newUserData.name}
              onChange={(e) => setNewUserData({...newUserData, name: e.target.value})}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: `2px solid ${errors.name ? 'red' : '#ccc'}`,
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = errors.name ? 'red' : '#ccc'}
            />
            {errors.name && <p style={{color: 'red', fontSize: '0.75em', marginTop: '0.5rem'}}>{errors.name}</p>}
          </div>
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="email">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={newUserData.email}
              onChange={(e) => setNewUserData({...newUserData, email: e.target.value})}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: `2px solid ${errors.email ? 'red' : '#ccc'}`,
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = errors.email ? 'red' : '#ccc'}
            />
            {errors.email && <p style={{color: 'red', fontSize: '0.75em', marginTop: '0.5rem'}}>{errors.email}</p>}
          </div>
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={newUserData.password}
              onChange={(e) => setNewUserData({...newUserData, password: e.target.value})}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: `2px solid ${errors.password ? 'red' : '#ccc'}`,
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = errors.password ? 'red' : '#ccc'}
            />
            {errors.password && <p style={{color: 'red', fontSize: '0.75em', marginTop: '0.5rem'}}>{errors.password}</p>}
          </div>
          <div style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: 'bold',
              color: '#555',
              fontSize: '0.9em'
            }} htmlFor="address">
              Address
            </label>
            <input
              type="text"
              id="address"
              value={newUserData.address}
              onChange={(e) => setNewUserData({...newUserData, address: e.target.value})}
              style={{
                width: '100%',
                padding: '0.8em 0',
                border: 'none',
                borderBottom: `2px solid ${errors.address ? 'red' : '#ccc'}`,
                outline: 'none',
                fontSize: '1em',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderBottomColor = '#2575fc'}
              onBlur={(e) => e.target.style.borderBottomColor = errors.address ? 'red' : '#ccc'}
            />
            {errors.address && <p style={{color: 'red', fontSize: '0.75em', marginTop: '0.5rem'}}>{errors.address}</p>}
          </div>
          <button
            type="submit"
            style={{
              width: '100%',
              padding: '1em',
              border: 'none',
              borderRadius: '25px',
              backgroundColor: '#2575fc',
              color: 'white',
              fontSize: '1.1em',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'background-color 0.3s, transform 0.2s'
            }}
            onMouseOver={(e) => e.target.style.backgroundColor = '#1a5acb'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#2575fc'}
          >
            Sign Up
          </button>
        </form>
        <div style={{ textAlign: 'center', marginTop: '1.5rem' }}>
          <p style={{ fontSize: '0.9em', color: '#555' }}>
            Already have an account?{' '}
            <a href="#" onClick={onGoToLogin} style={{ color: '#2575fc', textDecoration: 'none' }}>
              Log In
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

// A simple dashboard page visible only to authenticated users.
// NOTE: This is a placeholder and should be replaced with specific dashboards.
const DashboardPage = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <div style={{
      background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      fontFamily: 'sans-serif'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '2.5rem',
        borderRadius: '15px',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '500px',
        textAlign: 'center'
      }}>
        <h2 style={{
          fontSize: '2.5em',
          fontWeight: 'bold',
          color: '#2575fc',
          marginBottom: '1rem'
        }}>Welcome, {user.username}!</h2>
        <p style={{
          fontSize: '1.25em',
          color: '#555',
          marginBottom: '2rem'
        }}>
          You are logged in as a: <span style={{ fontWeight: 'bold' }}>{user.role}</span>
        </p>
        <button
          onClick={logout}
          style={{
            backgroundColor: '#ef4444',
            color: 'white',
            fontWeight: 'bold',
            padding: '0.75rem 1.5rem',
            borderRadius: '0.5rem',
            border: 'none',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}
          onMouseOver={(e) => e.target.style.backgroundColor = '#dc2626'}
          onMouseOut={(e) => e.target.style.backgroundColor = '#ef4444'}
        >
          Logout
        </button>
      </div>
    </div>
  );
};


// --- SYSTEM ADMINISTRATOR DASHBOARD COMPONENT ---
const SysAdminDashboardPage = () => {
  const { user, logout } = useContext(AuthContext);

  // State to hold form data and validation errors
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    password: '',
    address: '',
    role: 'Normal User'
  });
  const [errors, setErrors] = useState({});

  // Mock Data for the dashboard
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john.d@example.com', address: '123 Main St', role: 'Normal User' },
    { id: 2, name: 'Jane Smith', email: 'jane.s@example.com', address: '456 Oak Ave', role: 'Store Owner', rating: 4.5 },
    { id: 3, name: 'Admin User', email: 'admin.u@example.com', address: '789 Pine Rd', role: 'System Administrator' },
    { id: 4, name: 'Bob Johnson', email: 'bob.j@example.com', address: '101 Elm Blvd', role: 'Normal User' },
    { id: 5, name: 'Store Owner 2', email: 'so2@example.com', address: '202 Maple Dr', role: 'Store Owner', rating: 3.8 },
  ]);

  const [stores, setStores] = useState([
    { id: 1, name: 'The Coffee Shop', email: 'coffee@shop.com', address: '123 Main St', rating: 4.5 },
    { id: 2, name: 'Bookworms Inc.', email: 'books@inc.com', address: '456 Oak Ave', rating: 4.8 },
    { id: 3, name: 'The Tech Hub', email: 'tech@hub.com', address: '789 Pine Rd', rating: 4.2 },
  ]);

  const totalUsers = users.length;
  const totalStores = stores.length;
  // A simple way to get a mock total rating count
  const totalRatings = stores.reduce((sum, store) => sum + store.rating, 0).toFixed(1);

  const [searchTerm, setSearchTerm] = useState('');
  
  const handleFilterChange = (e) => {
    setSearchTerm(e.target.value);
  };
  
  // Validation function for the "Add New User" form
  const validateForm = () => {
    const newErrors = {};
    if (!newUserData.name || newUserData.name.length < 20 || newUserData.name.length > 60) {
      newErrors.name = 'Name must be between 20 and 60 characters.';
    }
    if (!newUserData.email) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(newUserData.email)) {
      newErrors.email = 'Email address is invalid.';
    }
    if (!newUserData.password || newUserData.password.length < 8 || newUserData.password.length > 16) {
      newErrors.password = 'Password must be 8-16 characters long.';
    } else if (!/[A-Z]/.test(newUserData.password) || !/[!@#$%^&*(),.?":{}|<>]/.test(newUserData.password)) {
      newErrors.password = 'Password must include at least one uppercase letter and one special character.';
    }
    if (!newUserData.address || newUserData.address.length > 400) {
      newErrors.address = 'Address cannot exceed 400 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddUser = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const newUser = {
        id: users.length + 1,
        name: newUserData.name,
        email: newUserData.email,
        password: newUserData.password,
        address: newUserData.address,
        role: newUserData.role,
      };
      setUsers([...users, newUser]);
      // Clear form fields after successful submission
      setNewUserData({ name: '', email: '', password: '', address: '', role: 'Normal User' });
      setErrors({});
      console.log('Added new user:', newUser);
    }
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{
      fontFamily: 'sans-serif',
      backgroundColor: '#f4f7f9',
      minHeight: '100vh',
      padding: '2rem'
    }}>
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem 0',
        borderBottom: '2px solid #e0e0e0',
        marginBottom: '2rem'
      }}>
        <h1 style={{ color: '#333', fontSize: '2em' }}>Admin Dashboard</h1>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <p style={{ marginRight: '1rem', color: '#555' }}>Logged in as: <span style={{ fontWeight: 'bold' }}>{user.username}</span></p>
          <button onClick={logout} style={{
            backgroundColor: '#ef4444',
            color: 'white',
            fontWeight: 'bold',
            padding: '0.5rem 1rem',
            borderRadius: '0.5rem',
            border: 'none',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}>
            Logout
          </button>
        </div>
      </header>

      {/* Stats Overview Section */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '1.5rem',
        marginBottom: '2rem'
      }}>
        <div style={{ padding: '1.5rem', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <h3 style={{ fontSize: '1.25em', color: '#6a11cb', marginBottom: '0.5rem' }}>Total Users</h3>
          <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#333' }}>{totalUsers}</p>
        </div>
        <div style={{ padding: '1.5rem', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <h3 style={{ fontSize: '1.25em', color: '#2575fc', marginBottom: '0.5rem' }}>Total Stores</h3>
          <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#333' }}>{totalStores}</p>
        </div>
        <div style={{ padding: '1.5rem', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <h3 style={{ fontSize: '1.25em', color: '#4CAF50', marginBottom: '0.5rem' }}>Total Ratings</h3>
          <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#333' }}>{totalRatings}</p>
        </div>
      </div>

      {/* User Management Section */}
      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>User Management</h2>

        {/* Add New User Form */}
        <div style={{ marginBottom: '2rem', padding: '1.5rem', border: '1px solid #e0e0e0', borderRadius: '8px' }}>
          <h3 style={{ fontSize: '1.25em', color: '#333', marginBottom: '1rem' }}>Add New User</h3>
          <form onSubmit={handleAddUser} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <input type="text" placeholder="Name" value={newUserData.name} onChange={(e) => setNewUserData({...newUserData, name: e.target.value})} style={{ padding: '0.75rem', border: `1px solid ${errors.name ? 'red' : '#ccc'}`, borderRadius: '5px' }} />
            {errors.name && <p style={{color: 'red', fontSize: '0.75em', gridColumn: 'span 2'}}>{errors.name}</p>}
            
            <input type="email" placeholder="Email" value={newUserData.email} onChange={(e) => setNewUserData({...newUserData, email: e.target.value})} style={{ padding: '0.75rem', border: `1px solid ${errors.email ? 'red' : '#ccc'}`, borderRadius: '5px' }} />
            {errors.email && <p style={{color: 'red', fontSize: '0.75em', gridColumn: 'span 2'}}>{errors.email}</p>}
            
            <input type="password" placeholder="Password" value={newUserData.password} onChange={(e) => setNewUserData({...newUserData, password: e.target.value})} style={{ padding: '0.75rem', border: `1px solid ${errors.password ? 'red' : '#ccc'}`, borderRadius: '5px' }} />
            {errors.password && <p style={{color: 'red', fontSize: '0.75em', gridColumn: 'span 2'}}>{errors.password}</p>}
            
            <input type="text" placeholder="Address" value={newUserData.address} onChange={(e) => setNewUserData({...newUserData, address: e.target.value})} style={{ padding: '0.75rem', border: `1px solid ${errors.address ? 'red' : '#ccc'}`, borderRadius: '5px' }} />
            {errors.address && <p style={{color: 'red', fontSize: '0.75em', gridColumn: 'span 2'}}>{errors.address}</p>}
            
            <select value={newUserData.role} onChange={(e) => setNewUserData({...newUserData, role: e.target.value})} style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }}>
              <option value="Normal User">Normal User</option>
              <option value="Store Owner">Store Owner</option>
              <option value="System Administrator">System Administrator</option>
            </select>
            <button type="submit" style={{
              backgroundColor: '#4CAF50', color: 'white', padding: '0.75rem', border: 'none', borderRadius: '5px', cursor: 'pointer', transition: 'background-color 0.3s'
            }}>Add User</button>
          </form>
        </div>

        {/* User List */}
        <div style={{ marginBottom: '1.5rem' }}>
          <h3 style={{ fontSize: '1.25em', color: '#333', marginBottom: '1rem' }}>User List</h3>
          <input
            type="text"
            placeholder="Filter by Name, Email, Address, or Role..."
            value={searchTerm}
            onChange={handleFilterChange}
            style={{ width: '100%', padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px', marginBottom: '1rem' }}
          />
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#f2f2f2' }}>
                <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Name</th>
                <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Email</th>
                <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Address</th>
                <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Role</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user.id} style={{ borderBottom: '1px solid #eee' }}>
                  <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{user.name}</td>
                  <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{user.email}</td>
                  <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{user.address}</td>
                  <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>
                    {user.role}
                    {user.role === 'Store Owner' && <span style={{ marginLeft: '0.5rem', color: '#f59e0b' }}>- {user.rating} ★</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Store Management Section */}
      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>Store Management</h2>
        <input
          type="text"
          placeholder="Filter stores..."
          value={searchTerm}
          onChange={handleFilterChange}
          style={{ width: '100%', padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px', marginBottom: '1rem' }}
        />
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f2f2f2' }}>
              <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Name</th>
              <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Email</th>
              <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Address</th>
              <th style={{ padding: '0.75rem', border: '1px solid #ddd', textAlign: 'left' }}>Rating</th>
            </tr>
          </thead>
          <tbody>
            {filteredStores.map(store => (
              <tr key={store.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{store.name}</td>
                <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{store.email}</td>
                <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{store.address}</td>
                <td style={{ padding: '0.75rem', border: '1px solid #ddd' }}>{store.rating} ★</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- NEW NORMAL USER DASHBOARD COMPONENT ---
const NormalUserDashboardPage = () => {
  const { user, logout } = useContext(AuthContext);

  const [stores, setStores] = useState([
    { id: 1, name: 'The Coffee Shop', address: '123 Main St', overallRating: 4.5, userRating: 0 },
    { id: 2, name: 'Bookworms Inc.', address: '456 Oak Ave', overallRating: 4.8, userRating: 0 },
    { id: 3, name: 'The Tech Hub', address: '789 Pine Rd', overallRating: 4.2, userRating: 0 },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [passwordChange, setPasswordChange] = useState({ current: '', new: '', confirm: '' });
  const [passwordMessage, setPasswordMessage] = useState('');
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  const handleRatingSubmit = (storeId, newRating) => {
    setStores(stores.map(store =>
      store.id === storeId ? { ...store, userRating: newRating } : store
    ));
    // In a real app, you would make an API call here to save the rating.
    console.log(`Rating for store ${storeId} submitted: ${newRating}`);
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    setPasswordMessage('');
    if (passwordChange.new !== passwordChange.confirm) {
      setPasswordMessage('New passwords do not match.');
      return;
    }
    // In a real app, you would make an API call to change the password.
    console.log('Password change submitted:', passwordChange);
    setPasswordMessage('Password updated successfully!');
    setPasswordChange({ current: '', new: '', confirm: '' });
  };

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{
      fontFamily: 'sans-serif',
      backgroundColor: '#f4f7f9',
      minHeight: '100vh',
      padding: '2rem'
    }}>
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem 0',
        borderBottom: '2px solid #e0e0e0',
        marginBottom: '2rem'
      }}>
        <h1 style={{ color: '#333', fontSize: '2em' }}>Normal User Dashboard</h1>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <p style={{ marginRight: '1rem', color: '#555' }}>Logged in as: <span style={{ fontWeight: 'bold' }}>{user.username}</span></p>
          <button onClick={logout} style={{
            backgroundColor: '#ef4444',
            color: 'white',
            fontWeight: 'bold',
            padding: '0.5rem 1rem',
            borderRadius: '0.5rem',
            border: 'none',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}>
            Logout
          </button>
        </div>
      </header>

      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>Store Ratings</h2>
        <div style={{ marginBottom: '1rem' }}>
          <input
            type="text"
            placeholder="Search stores by name or address..."
            value={searchTerm}
            onChange={handleSearch}
            style={{ width: '100%', padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }}
          />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
          {filteredStores.map(store => (
            <div key={store.id} style={{ padding: '1rem', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#fafafa' }}>
              <h3 style={{ fontSize: '1.25em', fontWeight: 'bold', color: '#333' }}>{store.name}</h3>
              <p style={{ color: '#666', fontSize: '0.9em' }}>{store.address}</p>
              <p style={{ color: '#555', marginTop: '0.5rem' }}>Overall Rating: <span style={{ fontWeight: 'bold', color: '#f59e0b' }}>{store.overallRating} ★</span></p>
              <p style={{ color: '#555' }}>Your Rating: <span style={{ fontWeight: 'bold' }}>{store.userRating > 0 ? `${store.userRating} ★` : 'Not rated'}</span></p>
              <div style={{ marginTop: '0.5rem' }}>
                <span style={{ marginRight: '1rem' }}>Submit/Update Rating:</span>
                {[1, 2, 3, 4, 5].map(rating => (
                  <button
                    key={rating}
                    onClick={() => handleRatingSubmit(store.id, rating)}
                    style={{
                      border: 'none',
                      backgroundColor: 'transparent',
                      cursor: 'pointer',
                      fontSize: '1.2rem',
                      color: rating <= store.userRating ? '#f59e0b' : '#ccc',
                      transition: 'color 0.2s'
                    }}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.75em', fontWeight: 'bold', color: '#333', marginBottom: '1.5rem' }}>Update Password</h2>
        <button onClick={() => setShowPasswordForm(!showPasswordForm)} style={{
          backgroundColor: '#2575fc',
          color: 'white',
          padding: '0.75rem 1.5rem',
          borderRadius: '0.5rem',
          border: 'none',
          cursor: 'pointer',
          transition: 'background-color 0.3s'
        }}>
          {showPasswordForm ? 'Hide Form' : 'Show Password Form'}
        </button>
        {showPasswordForm && (
          <form onSubmit={handlePasswordChange} style={{ marginTop: '1.5rem' }}>
            {passwordMessage && <p style={{ color: passwordMessage.includes('successfully') ? 'green' : 'red', marginBottom: '1rem' }}>{passwordMessage}</p>}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
              <input type="password" placeholder="Current Password" value={passwordChange.current} onChange={(e) => setPasswordChange({ ...passwordChange, current: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <input type="password" placeholder="New Password" value={passwordChange.new} onChange={(e) => setPasswordChange({ ...passwordChange, new: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <input type="password" placeholder="Confirm New Password" value={passwordChange.confirm} onChange={(e) => setPasswordChange({ ...passwordChange, confirm: e.target.value })} required style={{ padding: '0.75rem', border: '1px solid #ccc', borderRadius: '5px' }} />
              <button type="submit" style={{
                backgroundColor: '#4CAF50', color: 'white', padding: '0.75rem 1.5rem', border: 'none', borderRadius: '5px', cursor: 'pointer', transition: 'background-color 0.3s'
              }}>
                Update Password
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
// The main App component that handles routing based on authentication state.
const App = () => {
  const { user } = useContext(AuthContext);
  // We use a state variable for basic client-side routing.
  const [currentPage, setCurrentPage] = useState('login');

  useEffect(() => {
    // If a user is logged in, always show the dashboard.
    if (user) {
      setCurrentPage('dashboard');
    }
  }, [user]);

  // Conditional rendering based on the current page and user authentication status.
  switch (currentPage) {
    case 'login':
      return <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
    case 'signup':
      return <SignUpPage onRegisterSuccess={() => setCurrentPage('login')} onGoToLogin={() => setCurrentPage('login')} />;
    case 'dashboard':
      // Show the appropriate dashboard based on the user's role
      if (user && user.role === 'System Administrator') {
        return <SysAdminDashboardPage />;
      }
      if (user && user.role === 'Normal User') {
        return <NormalUserDashboardPage />;
      }
      return user ? <DashboardPage /> : <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
    default:
      return <LoginPage onLoginSuccess={() => setCurrentPage('dashboard')} onGoToSignup={() => setCurrentPage('signup')} />;
  }
};

// This is the default export required by the system.
// We wrap our App with the AuthProvider to make the authentication context available everywhere.
const WrappedApp = () => (
  <AuthProvider>
    <App />
  </AuthProvider>
);

export default WrappedApp;
