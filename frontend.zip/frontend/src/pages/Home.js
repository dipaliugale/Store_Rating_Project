import React from "react";
import { useAuth } from "../content/AuthContext";
import { useNavigate } from "react-router-dom";

function Home() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();           // clear user from context
    navigate("/login"); // redirect to login page
  };

  return (
    <div>
      {user ? (
        <>
          <h2>Welcome, {user.name}!</h2>
          <p>Browse stores and give your ratings!</p>
          <button onClick={handleLogout}>Logout</button>
        </>
      ) : (
        <>
          <h2>You are not logged in.</h2>
          <p>Please <a href="/login">Login</a> or <a href="/register">Register</a></p>
        </>
      )}
    </div>
  );
}

export default Home;
